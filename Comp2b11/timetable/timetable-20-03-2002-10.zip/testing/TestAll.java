
package timetable.testing ;

import junit.framework.* ;

public class TestAll
{
    public static Test suite()
    {
       	TestSuite suite = new TestSuite("All Tests") ;
	suite.addTestSuite(TimeTableDataStructureTest.class) ;
	//suite.addTestSuite(URLDataStructureTest.URLDataListTest.class) ; VALID< BUT SUPER not workin
	suite.addTestSuite(URLDataStructureTest.class) ;
	return suite ;
    }
    
    public static void main(String[] args)
    {
        junit.textui.TestRunner.run(suite()) ;
    }
}  

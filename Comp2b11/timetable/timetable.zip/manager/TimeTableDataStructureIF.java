
package timetable.manager ;

public interface TimeTableDataStructureIF
{

    public String getNextLecture(String urlList, String course, int day, int hour, String current) ;
    
}
